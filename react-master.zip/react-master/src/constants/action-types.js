export const APP_LOAD = 'APP_LOAD';

export default { APP_LOAD };
